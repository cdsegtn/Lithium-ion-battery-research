# ML-identify-battery-degradation
This software package implements the Gaussian Process method (GPML tool) to estimate the state of health and remaining useful lift of the Li-ion battery from impedance spectrum.

Please unzip the Code-Matlab to run the examples. 
The details are written in "Readme.txt".
